TOKEN = '1460715576:AAHnGniu7iks40tr7wvAvfGF0fbyGa17gPw'

keys = {
    'биткоин' : 'BTC',
    'эфириум' : 'ETH',
    'доллар' : 'USD',
}